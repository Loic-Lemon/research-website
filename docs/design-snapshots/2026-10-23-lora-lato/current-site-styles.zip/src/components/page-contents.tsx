'use client';

import { ChevronDown } from "lucide-react";
import { RefObject, useEffect, useId, useRef, useState } from "react";
import { createPortal } from "react-dom";

interface ContentsItem {
  id: string;
  label: string;
}

export function PageContents({ contentRef }: { contentRef: RefObject<HTMLDivElement | null> }) {
  const [items, setItems] = useState<ContentsItem[]>([]);
  const [activeId, setActiveId] = useState("");
  const [expanded, setExpanded] = useState<boolean | null>(null);
  const navRef = useRef<HTMLElement>(null);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const [mobileHost, setMobileHost] = useState<HTMLElement | null>(null);
  const isExpanded = mobileHost ? expanded === true : expanded ?? items.length <= 3;
  const prefix = useId();
  const nextId = useRef(0);

  useEffect(() => {
    const mobile = window.matchMedia("(max-width: 767px)");
    const updateHost = () => {
      setMobileHost(mobile.matches ? document.getElementById("mobile-page-contents") : null);
      setExpanded(null);
    };
    updateHost();
    mobile.addEventListener("change", updateHost);
    return () => mobile.removeEventListener("change", updateHost);
  }, []);

  useEffect(() => {
    if (!mobileHost || !isExpanded) return;
    const closeOutside = (event: PointerEvent) => {
      if (!navRef.current?.contains(event.target as Node)) setExpanded(false);
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setExpanded(false);
      toggleRef.current?.focus({ preventScroll: true });
    };
    document.addEventListener("pointerdown", closeOutside);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("pointerdown", closeOutside);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [mobileHost, isExpanded]);

  useEffect(() => {
    const content = contentRef.current;
    if (!content) return;

    const updateContents = () => {
      const sections = Array.from(content.querySelectorAll<HTMLElement>("[data-toc-label], h2"));
      const entries = Array.from(content.querySelectorAll<HTMLElement>("h3"));
      const targets = sections.length > 1 ? sections : entries.length > 1 ? entries : [...sections, ...entries];
      const updated = targets.map((element) => {
        if (!element.id) element.id = `${prefix}-${nextId.current++}`;
        return { id: element.id, label: element.dataset.tocLabel || element.textContent?.trim() || "" };
      }).filter((item) => item.label);

      setItems((previous) => previous.length === updated.length && previous.every((item, index) =>
        item.id === updated[index].id && item.label === updated[index].label
      ) ? previous : updated);
    };

    updateContents();
    const observer = new MutationObserver(updateContents);
    observer.observe(content, { childList: true, subtree: true, characterData: true });
    return () => observer.disconnect();
  }, [contentRef, prefix]);

  useEffect(() => {
    const updateActive = () => {
      let current = items[0]?.id || "";
      for (const item of items) {
        if ((document.getElementById(item.id)?.getBoundingClientRect().top ?? Infinity) <= (navRef.current?.getBoundingClientRect().bottom ?? 64) + 20) current = item.id;
      }
      if (window.scrollY > 0 && window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 2) {
        current = items[items.length - 1]?.id || current;
      }
      setActiveId(current);
    };

    const updateLayout = () => {
      if (navRef.current) {
        const bounds = navRef.current.getBoundingClientRect();
        const scrollPadding = parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop) || 0;
        const clearance = mobileHost ? Math.max(0, bounds.bottom + 16 - scrollPadding) : bounds.height + 16;
        contentRef.current?.style.setProperty("--page-contents-clearance", `${clearance}px`);
      }
      updateActive();
    };
    updateLayout();
    const observer = new ResizeObserver(updateLayout);
    if (navRef.current) observer.observe(navRef.current);
    window.addEventListener("scroll", updateActive, { passive: true });
    window.addEventListener("resize", updateActive);
    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", updateActive);
      window.removeEventListener("resize", updateActive);
    };
  }, [items, contentRef, mobileHost]);

  if (items.length < 2) return null;

  const contents = (
    <nav ref={navRef} aria-label="On this page" className={mobileHost ? "relative z-30 min-w-0 rounded border border-foreground/15 bg-background/95 px-3 shadow-sm backdrop-blur-md" : "sticky top-16 z-30 order-first mb-6 hidden min-w-0 rounded-lg border border-foreground/15 bg-background/95 px-3 py-1 shadow-[0_4px_16px_-8px_rgb(0_0_0/0.22)] backdrop-blur-md md:block"}>
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
        <button
          ref={toggleRef}
          type="button"
          aria-label={isExpanded ? "Collapse page contents" : "Expand page contents"}
          aria-expanded={isExpanded}
          aria-controls={`${prefix}-links`}
          onClick={() => setExpanded(!isExpanded)}
          className={`flex shrink-0 items-center gap-2 rounded-sm text-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent ${mobileHost ? "h-[42px] w-full" : "min-h-6"} ${isExpanded ? "" : "w-full"}`}
        >
          <span className="whitespace-nowrap text-[11px] uppercase tracking-[0.14em]">On this page</span>
          {!isExpanded && !mobileHost && <span className="ml-auto text-[11px]">{items.length} sections</span>}
          <ChevronDown aria-hidden="true" size={13} className={`ml-auto shrink-0 transition-transform motion-reduce:transition-none ${isExpanded ? "rotate-180" : ""}`} />
        </button>
        <div id={`${prefix}-links`} hidden={!isExpanded} className={`max-h-64 min-w-0 overflow-y-auto ${!isExpanded ? "hidden" : mobileHost ? "absolute right-0 top-[calc(100%+0.5rem)] grid w-[min(19rem,calc(100vw-2rem))] gap-0.5 rounded-lg border border-foreground/15 bg-background/95 p-2 shadow-lg backdrop-blur-md" : items.length <= 3 ? "flex basis-auto flex-wrap gap-x-4" : "grid basis-full gap-0.5"}`}>
          {items.map((item) => (
            <a
              key={item.id}
              href={`#${encodeURIComponent(item.id)}`}
              aria-current={activeId === item.id ? "location" : undefined}
              className={`inline-flex min-w-6 items-center leading-relaxed underline-offset-4 transition-colors hover:text-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent ${mobileHost ? "min-h-11 rounded px-2 text-sm hover:bg-foreground/5" : "min-h-6 text-[11px]"} ${activeId === item.id ? "text-accent underline" : "text-muted"}`}
              onClick={() => { if (mobileHost || items.length > 3) setExpanded(false); }}
            >
              {item.label}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );

  return mobileHost ? createPortal(contents, mobileHost) : contents;
}
