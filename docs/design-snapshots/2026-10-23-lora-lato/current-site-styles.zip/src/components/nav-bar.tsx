'use client';
import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Section } from "@/data/section-order";

const quickLinks = [
  { label: "Start", section: null as Section | null },
  { label: "Research", section: Section.Portfolio },
  { label: "Publications", section: Section.Publication },
  { label: "Timeline", section: Section.Timeline },
  { label: "Awards", section: Section.Award },
  { label: "Extra", section: Section.Extra },
];

interface NavBarProps {
  activeSection?: Section | null;
  onNavigate?: (section: Section | null) => void;
}

export function NavBar({ activeSection, onNavigate }: NavBarProps) {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!menuOpen) return;

    const handlePointerDown = (event: PointerEvent) => {
      if (!navRef.current?.contains(event.target as Node)) setMenuOpen(false);
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setMenuOpen(false);
      menuButtonRef.current?.focus({ preventScroll: true });
    };
    const desktop = window.matchMedia("(min-width: 768px)");
    const closeMenu = () => setMenuOpen(false);
    const contentsHost = document.getElementById("mobile-page-contents");

    document.addEventListener("pointerdown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);
    desktop.addEventListener("change", closeMenu);
    contentsHost?.addEventListener("click", closeMenu);
    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
      desktop.removeEventListener("change", closeMenu);
      contentsHost?.removeEventListener("click", closeMenu);
    };
  }, [menuOpen]);

  const handleClick = (section: Section | null) => {
    setMenuOpen(false);
    if (menuOpen) menuButtonRef.current?.focus({ preventScroll: true });
    if (onNavigate) {
      onNavigate(section);
    } else {
      const params = new URLSearchParams();
      if (section) params.set("section", section);
      const href = params.toString() ? `/?${params.toString()}` : '/';
      router.push(href);
    }
  };

  return (
    <header
      ref={navRef}
      data-open={menuOpen}
      className="site-nav fixed left-4 right-4 top-[max(1rem,env(safe-area-inset-top))] z-50 md:left-0 md:right-0 md:top-0 md:bg-background"
      onBlur={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget)) setMenuOpen(false);
      }}
    >
      <div className="flex items-start gap-2 md:contents">
      <button
        ref={menuButtonRef}
        type="button"
        className="menu-toggle flex h-11 items-center gap-2.5 rounded border border-foreground/15 bg-background px-3 text-sm text-foreground shadow-sm transition-colors hover:bg-surface-2 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent md:hidden"
        aria-label={menuOpen ? "Close quick links" : "Open quick links"}
        aria-expanded={menuOpen}
        aria-controls="quick-links"
        onClick={() => setMenuOpen((open) => !open)}
      >
        <span className="menu-toggle-icon" aria-hidden="true">
          <span />
          <span />
          <span />
        </span>
        <span aria-hidden="true" className="text-base leading-none">🍔</span>
        <span>{menuOpen ? "Close" : "Menu"}</span>
      </button>
      <div id="mobile-page-contents" className="min-w-0 flex-1 md:hidden" />
      </div>
      <div
        className="quick-links-panel absolute left-0 top-[calc(100%+0.75rem)] w-full overflow-y-auto rounded border border-foreground/15 bg-background/70 p-1 shadow-md backdrop-blur-md md:static md:overflow-visible md:rounded-none md:border-0 md:bg-transparent md:p-0 md:py-2 md:shadow-sm md:backdrop-blur-none"
      >
        <nav
          id="quick-links"
          aria-label="Quick links"
          className="flex flex-col font-sans text-base leading-relaxed text-foreground md:flex-row md:items-center md:justify-center md:gap-2"
        >
          {quickLinks.map((link) => (
            <button
              key={link.label}
              type="button"
              aria-current={activeSection === link.section ? "page" : undefined}
              className={`flex min-h-11 items-center rounded-sm px-3 text-left transition-colors hover:bg-foreground/5 hover:text-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent md:mx-2 md:min-h-0 md:rounded-none md:bg-transparent md:p-0 md:italic md:hover:bg-transparent ${
                activeSection === link.section ? "bg-foreground/5 font-medium text-accent md:bg-transparent md:font-bold md:underline" : "text-foreground/80 md:text-foreground/60"
              }`}
              onClick={() => handleClick(link.section)}
            >
              <span className="nav-link" data-label={link.label}>
                <span>{link.label}</span>
              </span>
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
}
