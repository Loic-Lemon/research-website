import { StaticImageData } from 'next/image';
import frontpage from './frontpage.png';
import banner from './banner.png';
import chase from './chase.webp';

export interface AboutMe {
  name: string;
  title: string;
  institution: string;
  description: string;
  researchDescription?: string;
  researchImage?: StaticImageData;
  researchConclusion?: string;
  email: string;
  imageUrl?: string | StaticImageData;
  bannerImage?: string | StaticImageData;
  blogUrl?: string;
  cvUrl?: string;
  labUrl?: string;
  googleScholarUrl?: string;
  twitterUsername?: string;
  githubUsername?: string;
  linkedinUsername?: string;
  funDescription?: string; // Gets placed in the left sidebar
  secretDescription?: string; // Gets placed in the bottom
  pronunciation?: string;
  altName?: string;
  institutionUrl?: string;
}

export const aboutMe: AboutMe = {
  name: "Loic Lorente Lemoine",
  pronunciation: "/ˈloʊ.ɪk lɔːˈrɛn.teɪ ləˈmwɑːn/",
  title: "PhD CompSci",
  institution: "Cardiff University",
  // Note that links work in the description
  description: `<p>I'm Loic, a <strong>PhD student</strong> in the School of Computer Science and Informatics at <strong>Cardiff University</strong> + <a href="https://www.agilecps.org/" target="_blank" rel="noopener noreferrer"><strong>AGILE Lab</strong></a>.</p>
  <ul style="margin:12px 0;padding-left:1.25rem;list-style:disc">
    <li style="margin:0 0 8px">I completed a <strong>BSc in Computer Science</strong> at Cardiff University in 2024, graduating with <strong>First Class Honours</strong>. My dissertation received the <strong>Best Undergraduate Dissertation award</strong> in CompSci.</li>
    <li style="margin:0 0 8px">I completed an <strong>MPhil</strong> with Dr Amir Javed, researching <strong>machine-learning methods for intrusion detection in vehicles</strong>. I completed my Viva with <strong>no corrections</strong>.</li>
    <li style="color:rgb(var(--accent))">I am now pursuing a <strong>PhD</strong> under the supervision of Dr Nick Pham.</li>
  </ul>
  `,
  researchDescription: `<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
  <p style="margin-top:12px">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>`,
  researchImage: chase,
  researchConclusion: "Even though there is a focus on stress and seizures, the systems and methodologies presented in my work can be considered universal to other biosignal systems. I hope that the research can contribute towards healthcare companies that improve quality of life.",
  email: "lorentelemoinel@cardiff.ac.uk",
  imageUrl: frontpage,
  bannerImage: banner,
  // googleScholarUrl: "https://scholar.google.com/citations?user=bWtMl_MAAAAJ",
  labUrl: "https://www.agilecps.org/",
  githubUsername: "loic-lemon",
  linkedinUsername: "lemoineloic",
  // twitterUsername: "janesmith",
  // blogUrl: "https://fountain.lorentel.com",
  cvUrl: "https://lorentel.com",
  institutionUrl: "https://www.cardiff.ac.uk/",
  // altName: "",
  // secretDescription: "",
};
